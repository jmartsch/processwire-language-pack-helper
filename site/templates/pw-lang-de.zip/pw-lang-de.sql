-- mysqldump-php https://github.com/ifsnop/mysqldump-php
--
-- Host: localhost	Database: processwire-lang-de
-- ------------------------------------------------------
-- Server version 	5.7.24
-- Date: Mon, 20 Jul 2020 16:30:09 +0200

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `processwire-lang-de`
--

/*!40000 DROP DATABASE IF EXISTS `processwire-lang-de`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `processwire-lang-de` /*!40100 DEFAULT CHARACTER SET utf8  COLLATE utf8_general_ci */;

USE `processwire-lang-de`;

--
-- Table structure for table `caches`
--

DROP TABLE IF EXISTS `caches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caches` (
  `name` varchar(250) NOT NULL,
  `data` mediumtext NOT NULL,
  `expires` datetime NOT NULL,
  PRIMARY KEY (`name`),
  KEY `expires` (`expires`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caches`
--

LOCK TABLES `caches` WRITE;
/*!40000 ALTER TABLE `caches` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `caches` VALUES ('Modules.wire/modules/','AdminTheme/AdminThemeDefault/AdminThemeDefault.module\nAdminTheme/AdminThemeReno/AdminThemeReno.module\nAdminTheme/AdminThemeUikit/AdminThemeUikit.module\nFieldtype/FieldtypeCache.module\nFieldtype/FieldtypeCheckbox.module\nFieldtype/FieldtypeComments/CommentFilterAkismet.module\nFieldtype/FieldtypeComments/FieldtypeComments.module\nFieldtype/FieldtypeComments/InputfieldCommentsAdmin.module\nFieldtype/FieldtypeDatetime.module\nFieldtype/FieldtypeEmail.module\nFieldtype/FieldtypeFieldsetClose.module\nFieldtype/FieldtypeFieldsetOpen.module\nFieldtype/FieldtypeFieldsetTabOpen.module\nFieldtype/FieldtypeFile.module\nFieldtype/FieldtypeFloat.module\nFieldtype/FieldtypeImage.module\nFieldtype/FieldtypeInteger.module\nFieldtype/FieldtypeModule.module\nFieldtype/FieldtypeOptions/FieldtypeOptions.module\nFieldtype/FieldtypePage.module\nFieldtype/FieldtypePageTable.module\nFieldtype/FieldtypePageTitle.module\nFieldtype/FieldtypePassword.module\nFieldtype/FieldtypeRepeater/FieldtypeFieldsetPage.module\nFieldtype/FieldtypeRepeater/FieldtypeRepeater.module\nFieldtype/FieldtypeRepeater/InputfieldRepeater.module\nFieldtype/FieldtypeSelector.module\nFieldtype/FieldtypeText.module\nFieldtype/FieldtypeTextarea.module\nFieldtype/FieldtypeToggle.module\nFieldtype/FieldtypeURL.module\nFileCompilerTags.module\nImage/ImageSizerEngineAnimatedGif/ImageSizerEngineAnimatedGif.module\nImage/ImageSizerEngineIMagick/ImageSizerEngineIMagick.module\nInputfield/InputfieldAsmSelect/InputfieldAsmSelect.module\nInputfield/InputfieldButton.module\nInputfield/InputfieldCheckbox.module\nInputfield/InputfieldCheckboxes/InputfieldCheckboxes.module\nInputfield/InputfieldCKEditor/InputfieldCKEditor.module\nInputfield/InputfieldDatetime/InputfieldDatetime.module\nInputfield/InputfieldEmail.module\nInputfield/InputfieldFieldset.module\nInputfield/InputfieldFile/InputfieldFile.module\nInputfield/InputfieldFloat.module\nInputfield/InputfieldForm.module\nInputfield/InputfieldHidden.module\nInputfield/InputfieldIcon/InputfieldIcon.module\nInputfield/InputfieldImage/InputfieldImage.module\nInputfield/InputfieldInteger.module\nInputfield/InputfieldMarkup.module\nInputfield/InputfieldName.module\nInputfield/InputfieldPage/InputfieldPage.module\nInputfield/InputfieldPageAutocomplete/InputfieldPageAutocomplete.module\nInputfield/InputfieldPageListSelect/InputfieldPageListSelect.module\nInputfield/InputfieldPageListSelect/InputfieldPageListSelectMultiple.module\nInputfield/InputfieldPageName/InputfieldPageName.module\nInputfield/InputfieldPageTable/InputfieldPageTable.module\nInputfield/InputfieldPageTitle/InputfieldPageTitle.module\nInputfield/InputfieldPassword/InputfieldPassword.module\nInputfield/InputfieldRadios/InputfieldRadios.module\nInputfield/InputfieldSelect.module\nInputfield/InputfieldSelectMultiple.module\nInputfield/InputfieldSelector/InputfieldSelector.module\nInputfield/InputfieldSubmit/InputfieldSubmit.module\nInputfield/InputfieldText.module\nInputfield/InputfieldTextarea.module\nInputfield/InputfieldToggle/InputfieldToggle.module\nInputfield/InputfieldURL.module\nJquery/JqueryCore/JqueryCore.module\nJquery/JqueryMagnific/JqueryMagnific.module\nJquery/JqueryTableSorter/JqueryTableSorter.module\nJquery/JqueryUI/JqueryUI.module\nJquery/JqueryWireTabs/JqueryWireTabs.module\nLanguageSupport/FieldtypePageTitleLanguage.module\nLanguageSupport/FieldtypeTextareaLanguage.module\nLanguageSupport/FieldtypeTextLanguage.module\nLanguageSupport/LanguageSupport.module\nLanguageSupport/LanguageSupportFields.module\nLanguageSupport/LanguageSupportPageNames.module\nLanguageSupport/LanguageTabs.module\nLanguageSupport/ProcessLanguage.module\nLanguageSupport/ProcessLanguageTranslator.module\nLazyCron.module\nMarkup/MarkupAdminDataTable/MarkupAdminDataTable.module\nMarkup/MarkupCache.module\nMarkup/MarkupHTMLPurifier/MarkupHTMLPurifier.module\nMarkup/MarkupPageArray.module\nMarkup/MarkupPageFields.module\nMarkup/MarkupPagerNav/MarkupPagerNav.module\nMarkup/MarkupRSS.module\nPage/PageFrontEdit/PageFrontEdit.module\nPagePathHistory.module\nPagePaths.module\nPagePermissions.module\nPageRender.module\nProcess/ProcessCommentsManager/ProcessCommentsManager.module\nProcess/ProcessField/ProcessField.module\nProcess/ProcessForgotPassword.module\nProcess/ProcessHome.module\nProcess/ProcessList.module\nProcess/ProcessLogger/ProcessLogger.module\nProcess/ProcessLogin/ProcessLogin.module\nProcess/ProcessModule/ProcessModule.module\nProcess/ProcessPageAdd/ProcessPageAdd.module\nProcess/ProcessPageClone.module\nProcess/ProcessPageEdit/ProcessPageEdit.module\nProcess/ProcessPageEditImageSelect/ProcessPageEditImageSelect.module\nProcess/ProcessPageEditLink/ProcessPageEditLink.module\nProcess/ProcessPageList/ProcessPageList.module\nProcess/ProcessPageLister/ProcessPageLister.module\nProcess/ProcessPageSearch/ProcessPageSearch.module\nProcess/ProcessPagesExportImport/ProcessPagesExportImport.module\nProcess/ProcessPageSort.module\nProcess/ProcessPageTrash.module\nProcess/ProcessPageType/ProcessPageType.module\nProcess/ProcessPageView.module\nProcess/ProcessPermission/ProcessPermission.module\nProcess/ProcessProfile/ProcessProfile.module\nProcess/ProcessRecentPages/ProcessRecentPages.module\nProcess/ProcessRole/ProcessRole.module\nProcess/ProcessTemplate/ProcessTemplate.module\nProcess/ProcessUser/ProcessUser.module\nSession/SessionHandlerDB/ProcessSessionDB.module\nSession/SessionHandlerDB/SessionHandlerDB.module\nSession/SessionLoginThrottle/SessionLoginThrottle.module\nSystem/SystemNotifications/FieldtypeNotifications.module\nSystem/SystemNotifications/SystemNotifications.module\nSystem/SystemUpdater/SystemUpdater.module\nTextformatter/TextformatterEntities.module\nTextformatter/TextformatterMarkdownExtra/TextformatterMarkdownExtra.module\nTextformatter/TextformatterNewlineBR.module\nTextformatter/TextformatterNewlineUL.module\nTextformatter/TextformatterPstripper.module\nTextformatter/TextformatterSmartypants/TextformatterSmartypants.module\nTextformatter/TextformatterStripTags.module','2010-04-08 03:10:01'),('ModulesUninstalled.info','{\"AdminThemeReno\":{\"name\":\"AdminThemeReno\",\"title\":\"Reno\",\"version\":17,\"versionStr\":\"0.1.7\",\"author\":\"Tom Reno (Renobird)\",\"summary\":\"Admin theme for ProcessWire 2.5+ by Tom Reno (Renobird)\",\"requiresVersions\":{\"AdminThemeDefault\":[\">=\",0]},\"autoload\":\"template=admin\",\"created\":1591964238,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeCache\":{\"name\":\"FieldtypeCache\",\"title\":\"Cache\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Caches the values of other fields for fewer runtime queries. Can also be used to combine multiple text fields and have them all be searchable under the cached field name.\",\"created\":1591964238,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"CommentFilterAkismet\":{\"name\":\"CommentFilterAkismet\",\"title\":\"Comment Filter: Akismet\",\"version\":200,\"versionStr\":\"2.0.0\",\"summary\":\"Uses the Akismet service to identify comment spam. Module plugin for the Comments Fieldtype.\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"created\":1591964238,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeComments\":{\"name\":\"FieldtypeComments\",\"title\":\"Comments\",\"version\":108,\"versionStr\":\"1.0.8\",\"summary\":\"Field that stores user posted comments for a single Page\",\"installs\":[\"InputfieldCommentsAdmin\"],\"created\":1591964238,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"InputfieldCommentsAdmin\":{\"name\":\"InputfieldCommentsAdmin\",\"title\":\"Comments Admin\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides an administrative interface for working with comments\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"created\":1591964238,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeOptions\":{\"name\":\"FieldtypeOptions\",\"title\":\"Select Options\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Field that stores single and multi select options.\",\"created\":1591964238,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypePageTable\":{\"name\":\"FieldtypePageTable\",\"title\":\"ProFields: Page Table\",\"version\":8,\"versionStr\":\"0.0.8\",\"summary\":\"A fieldtype containing a group of editable pages.\",\"installs\":[\"InputfieldPageTable\"],\"autoload\":true,\"created\":1591964238,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeFieldsetPage\":{\"name\":\"FieldtypeFieldsetPage\",\"title\":\"Fieldset (Page)\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Fieldset with fields isolated to separate namespace (page), enabling re-use of fields.\",\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"autoload\":true,\"created\":1591964238,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeRepeater\":{\"name\":\"FieldtypeRepeater\",\"title\":\"Repeater\",\"version\":106,\"versionStr\":\"1.0.6\",\"summary\":\"Maintains a collection of fields that are repeated for any number of times.\",\"installs\":[\"InputfieldRepeater\"],\"autoload\":true,\"created\":1591964238,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"InputfieldRepeater\":{\"name\":\"InputfieldRepeater\",\"title\":\"Repeater\",\"version\":106,\"versionStr\":\"1.0.6\",\"summary\":\"Repeats fields from another template. Provides the input for FieldtypeRepeater.\",\"requiresVersions\":{\"FieldtypeRepeater\":[\">=\",0]},\"created\":1591964238,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeSelector\":{\"name\":\"FieldtypeSelector\",\"title\":\"Selector\",\"version\":13,\"versionStr\":\"0.1.3\",\"author\":\"Avoine + ProcessWire\",\"summary\":\"Build a page finding selector visually.\",\"created\":1591964238,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeToggle\":{\"name\":\"FieldtypeToggle\",\"title\":\"Toggle (Yes\\/No)\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Configurable yes\\/no, on\\/off toggle alternative to a checkbox, plus optional \\u201cother\\u201d option.\",\"requiresVersions\":{\"InputfieldToggle\":[\">=\",0]},\"created\":1591964238,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FileCompilerTags\":{\"name\":\"FileCompilerTags\",\"title\":\"Tags File Compiler\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Enables {var} or {var.property} variables in markup sections of a file. Can be used with any API variable.\",\"created\":1591964238,\"installed\":false,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"ImageSizerEngineAnimatedGif\":{\"name\":\"ImageSizerEngineAnimatedGif\",\"title\":\"Animated GIF Image Sizer\",\"version\":1,\"versionStr\":\"0.0.1\",\"author\":\"Horst Nogajski\",\"summary\":\"Upgrades image manipulations for animated GIFs.\",\"created\":1591964238,\"installed\":false,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"ImageSizerEngineIMagick\":{\"name\":\"ImageSizerEngineIMagick\",\"title\":\"IMagick Image Sizer\",\"version\":3,\"versionStr\":\"0.0.3\",\"author\":\"Horst Nogajski\",\"summary\":\"Upgrades image manipulations to use PHP\'s ImageMagick library when possible.\",\"created\":1591964238,\"installed\":false,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"InputfieldPageAutocomplete\":{\"name\":\"InputfieldPageAutocomplete\",\"title\":\"Page Auto Complete\",\"version\":112,\"versionStr\":\"1.1.2\",\"summary\":\"Multiple Page selection using auto completion and sorting capability. Intended for use as an input field for Page reference fields.\",\"created\":1591964239,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"InputfieldPageTable\":{\"name\":\"InputfieldPageTable\",\"title\":\"ProFields: Page Table\",\"version\":13,\"versionStr\":\"0.1.3\",\"summary\":\"Inputfield to accompany FieldtypePageTable\",\"requiresVersions\":{\"FieldtypePageTable\":[\">=\",0]},\"created\":1591964239,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"InputfieldToggle\":{\"name\":\"InputfieldToggle\",\"title\":\"Toggle\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"A toggle providing similar input capability to a checkbox but much more configurable.\",\"created\":1591964239,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypePageTitleLanguage\":{\"name\":\"FieldtypePageTitleLanguage\",\"title\":\"Page Title (Multi-Language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"author\":\"Ryan Cramer\",\"summary\":\"Field that stores a page title in multiple languages. Use this only if you want title inputs created for ALL languages on ALL pages. Otherwise create separate languaged-named title fields, i.e. title_fr, title_es, title_fi, etc. \",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0],\"FieldtypeTextLanguage\":[\">=\",0]},\"created\":1591964239,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeTextareaLanguage\":{\"name\":\"FieldtypeTextareaLanguage\",\"title\":\"Textarea (Multi-language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Field that stores a multiple lines of text in multiple languages\",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0]},\"created\":1591964239,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeTextLanguage\":{\"name\":\"FieldtypeTextLanguage\",\"title\":\"Text (Multi-language)\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Field that stores a single line of text in multiple languages\",\"requiresVersions\":{\"LanguageSupportFields\":[\">=\",0]},\"created\":1591964239,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"LanguageSupportFields\":{\"name\":\"LanguageSupportFields\",\"title\":\"Languages Support - Fields\",\"version\":100,\"versionStr\":\"1.0.0\",\"author\":\"Ryan Cramer\",\"summary\":\"Required to use multi-language fields.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"installs\":[\"FieldtypePageTitleLanguage\",\"FieldtypeTextareaLanguage\",\"FieldtypeTextLanguage\"],\"autoload\":true,\"singular\":true,\"created\":1591964239,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"LanguageSupportPageNames\":{\"name\":\"LanguageSupportPageNames\",\"title\":\"Languages Support - Page Names\",\"version\":10,\"versionStr\":\"0.1.0\",\"author\":\"Ryan Cramer\",\"summary\":\"Required to use multi-language page names.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0],\"LanguageSupportFields\":[\">=\",0]},\"autoload\":true,\"singular\":true,\"created\":1591964239,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"LanguageTabs\":{\"name\":\"LanguageTabs\",\"title\":\"Languages Support - Tabs\",\"version\":114,\"versionStr\":\"1.1.4\",\"author\":\"adamspruijt, ryan\",\"summary\":\"Organizes multi-language fields into tabs for a cleaner easier to use interface.\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"autoload\":\"template=admin\",\"singular\":true,\"created\":1591964239,\"installed\":false,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"LazyCron\":{\"name\":\"LazyCron\",\"title\":\"Lazy Cron\",\"version\":102,\"versionStr\":\"1.0.2\",\"summary\":\"Provides hooks that are automatically executed at various intervals. It is called \'lazy\' because it\'s triggered by a pageview, so the interval is guaranteed to be at least the time requested, rather than exactly the time requested. This is fine for most cases, but you can make it not lazy by connecting this to a real CRON job. See the module file for details. \",\"href\":\"https:\\/\\/processwire.com\\/api\\/modules\\/lazy-cron\\/\",\"autoload\":true,\"singular\":true,\"created\":1591964239,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"MarkupCache\":{\"name\":\"MarkupCache\",\"title\":\"Markup Cache\",\"version\":101,\"versionStr\":\"1.0.1\",\"summary\":\"A simple way to cache segments of markup in your templates. \",\"href\":\"https:\\/\\/processwire.com\\/api\\/modules\\/markupcache\\/\",\"autoload\":true,\"singular\":true,\"created\":1591964239,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"MarkupPageFields\":{\"name\":\"MarkupPageFields\",\"title\":\"Markup Page Fields\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Adds $page->renderFields() and $page->images->render() methods that return basic markup for output during development and debugging.\",\"autoload\":true,\"singular\":true,\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true,\"permanent\":true},\"MarkupRSS\":{\"name\":\"MarkupRSS\",\"title\":\"Markup RSS Feed\",\"version\":103,\"versionStr\":\"1.0.3\",\"summary\":\"Renders an RSS feed. Given a PageArray, renders an RSS feed of them.\",\"created\":1591964240,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"PageFrontEdit\":{\"name\":\"PageFrontEdit\",\"title\":\"Front-End Page Editor\",\"version\":3,\"versionStr\":\"0.0.3\",\"author\":\"Ryan Cramer\",\"summary\":\"Enables front-end editing of page fields.\",\"icon\":\"cube\",\"permissions\":{\"page-edit-front\":\"Use the front-end page editor\"},\"autoload\":true,\"created\":1591964240,\"installed\":false,\"configurable\":\"PageFrontEditConfig.php\",\"namespace\":\"ProcessWire\\\\\",\"core\":true,\"license\":\"MPL 2.0\"},\"PagePathHistory\":{\"name\":\"PagePathHistory\",\"title\":\"Page Path History\",\"version\":5,\"versionStr\":\"0.0.5\",\"summary\":\"Keeps track of past URLs where pages have lived and automatically redirects (301 permament) to the new location whenever the past URL is accessed.\",\"autoload\":true,\"singular\":true,\"created\":1591964240,\"installed\":false,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"PagePaths\":{\"name\":\"PagePaths\",\"title\":\"Page Paths\",\"version\":1,\"versionStr\":\"0.0.1\",\"summary\":\"Enables page paths\\/urls to be queryable by selectors. Also offers potential for improved load performance. Builds an index at install (may take time on a large site). Currently supports only single languages sites.\",\"autoload\":true,\"singular\":true,\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"ProcessCommentsManager\":{\"name\":\"ProcessCommentsManager\",\"title\":\"Comments\",\"version\":10,\"versionStr\":\"0.1.0\",\"author\":\"Ryan Cramer\",\"summary\":\"Manage comments in your site outside of the page editor.\",\"icon\":\"comments\",\"requiresVersions\":{\"FieldtypeComments\":[\">=\",0]},\"permission\":\"comments-manager\",\"permissions\":{\"comments-manager\":\"Use the comments manager\"},\"created\":1591964240,\"installed\":false,\"searchable\":\"comments\",\"namespace\":\"ProcessWire\\\\\",\"core\":true,\"page\":{\"name\":\"comments\",\"parent\":\"setup\",\"title\":\"Comments\"},\"nav\":[{\"url\":\"?go=approved\",\"label\":\"Approved\"},{\"url\":\"?go=pending\",\"label\":\"Pending\"},{\"url\":\"?go=spam\",\"label\":\"Spam\"},{\"url\":\"?go=all\",\"label\":\"All\"}]},\"ProcessForgotPassword\":{\"name\":\"ProcessForgotPassword\",\"title\":\"Forgot Password\",\"version\":103,\"versionStr\":\"1.0.3\",\"summary\":\"Provides password reset\\/email capability for the Login process.\",\"permission\":\"page-view\",\"created\":1591964240,\"installed\":false,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"ProcessPageClone\":{\"name\":\"ProcessPageClone\",\"title\":\"Page Clone\",\"version\":104,\"versionStr\":\"1.0.4\",\"summary\":\"Provides ability to clone\\/copy\\/duplicate pages in the admin. Adds a &quot;copy&quot; option to all applicable pages in the PageList.\",\"permission\":\"page-clone\",\"permissions\":{\"page-clone\":\"Clone a page\",\"page-clone-tree\":\"Clone a tree of pages\"},\"autoload\":\"template=admin\",\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true,\"page\":{\"name\":\"clone\",\"title\":\"Clone\",\"parent\":\"page\",\"status\":1024}},\"ProcessPagesExportImport\":{\"name\":\"ProcessPagesExportImport\",\"title\":\"Pages Export\\/Import\",\"version\":1,\"versionStr\":\"0.0.1\",\"author\":\"Ryan Cramer\",\"summary\":\"Enables exporting and importing of pages. Development version, not yet recommended for production use.\",\"icon\":\"paper-plane-o\",\"permission\":\"page-edit-export\",\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true,\"page\":{\"name\":\"export-import\",\"parent\":\"page\",\"title\":\"Export\\/Import\"}},\"ProcessSessionDB\":{\"name\":\"ProcessSessionDB\",\"title\":\"Sessions\",\"version\":4,\"versionStr\":\"0.0.4\",\"summary\":\"Enables you to browse active database sessions.\",\"icon\":\"dashboard\",\"requiresVersions\":{\"SessionHandlerDB\":[\">=\",0]},\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true,\"page\":{\"name\":\"sessions-db\",\"parent\":\"access\",\"title\":\"Sessions\"}},\"SessionHandlerDB\":{\"name\":\"SessionHandlerDB\",\"title\":\"Session Handler Database\",\"version\":5,\"versionStr\":\"0.0.5\",\"summary\":\"Installing this module makes ProcessWire store sessions in the database rather than the file system. Note that this module will log you out after install or uninstall.\",\"installs\":[\"ProcessSessionDB\"],\"created\":1591964240,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"FieldtypeNotifications\":{\"name\":\"FieldtypeNotifications\",\"title\":\"Notifications\",\"version\":4,\"versionStr\":\"0.0.4\",\"summary\":\"Field that stores user notifications.\",\"requiresVersions\":{\"SystemNotifications\":[\">=\",0]},\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"SystemNotifications\":{\"name\":\"SystemNotifications\",\"title\":\"System Notifications\",\"version\":12,\"versionStr\":\"0.1.2\",\"summary\":\"Adds support for notifications in ProcessWire (currently in development)\",\"icon\":\"bell\",\"installs\":[\"FieldtypeNotifications\"],\"autoload\":true,\"created\":1591964240,\"installed\":false,\"configurable\":\"SystemNotificationsConfig.php\",\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"TextformatterMarkdownExtra\":{\"name\":\"TextformatterMarkdownExtra\",\"title\":\"Markdown\\/Parsedown Extra\",\"version\":130,\"versionStr\":\"1.3.0\",\"summary\":\"Markdown\\/Parsedown extra lightweight markup language by Emanuil Rusev. Based on Markdown by John Gruber.\",\"created\":1591964240,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"TextformatterNewlineBR\":{\"name\":\"TextformatterNewlineBR\",\"title\":\"Newlines to XHTML Line Breaks\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Converts newlines to XHTML line break <br \\/> tags. \",\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"TextformatterNewlineUL\":{\"name\":\"TextformatterNewlineUL\",\"title\":\"Newlines to Unordered List\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Converts newlines to <li> list items and surrounds in an <ul> unordered list. \",\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"TextformatterPstripper\":{\"name\":\"TextformatterPstripper\",\"title\":\"Paragraph Stripper\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Strips paragraph <p> tags that may have been applied by other text formatters before it. \",\"created\":1591964240,\"installed\":false,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"TextformatterSmartypants\":{\"name\":\"TextformatterSmartypants\",\"title\":\"SmartyPants Typographer\",\"version\":171,\"versionStr\":\"1.7.1\",\"summary\":\"Smart typography for web sites, by Michel Fortin based on SmartyPants by John Gruber. If combined with Markdown, it should be applied AFTER Markdown.\",\"created\":1591964240,\"installed\":false,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"core\":true,\"url\":\"https:\\/\\/github.com\\/michelf\\/php-smartypants\"},\"TextformatterStripTags\":{\"name\":\"TextformatterStripTags\",\"title\":\"Strip Markup Tags\",\"version\":100,\"versionStr\":\"1.0.0\",\"summary\":\"Strips HTML\\/XHTML Markup Tags\",\"created\":1591964240,\"installed\":false,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"core\":true},\"Helloworld\":{\"name\":\"Helloworld\",\"title\":\"Hello World\",\"version\":3,\"versionStr\":\"0.0.3\",\"summary\":\"An example module used for demonstration purposes.\",\"href\":\"https:\\/\\/processwire.com\",\"icon\":\"smile-o\",\"autoload\":true,\"singular\":true,\"created\":1572472518,\"installed\":false}}','2010-04-08 03:10:01'),('FileCompiler__6d6d9bc247b2869b92e3aabcb017520d','{\"source\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/ready.php\",\"hash\":\"e4d22030ea3ded041420279008ada175\",\"size\":1225,\"time\":1572475344,\"ns\":\"ProcessWire\"},\"target\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/ready.php\",\"hash\":\"e4d22030ea3ded041420279008ada175\",\"size\":1225,\"time\":1572475344}}','2010-04-08 03:10:10'),('Modules.site/modules/','Helloworld/Helloworld.module\nProcessWireUpgrade/ProcessWireUpgrade.module\nProcessWireUpgrade/ProcessWireUpgradeCheck.module','2010-04-08 03:10:01'),('FileCompiler__e6f0c4198167811b38550ad4f8210ece','{\"source\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/templates\\/admin.php\",\"hash\":\"9636f854995462a4cb877cb1204bc2fe\",\"size\":467,\"time\":1572472368,\"ns\":\"ProcessWire\"},\"target\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/templates\\/admin.php\",\"hash\":\"9636f854995462a4cb877cb1204bc2fe\",\"size\":467,\"time\":1572472368}}','2010-04-08 03:10:10'),('Modules.info','{\"148\":{\"name\":\"AdminThemeDefault\",\"title\":\"Default\",\"version\":14,\"autoload\":\"template=admin\",\"created\":1572472518,\"configurable\":19,\"namespace\":\"ProcessWire\\\\\"},\"160\":{\"name\":\"AdminThemeUikit\",\"title\":\"Uikit\",\"version\":30,\"requiresVersions\":{\"ProcessWire\":[\">=\",\"3.0.100\"]},\"autoload\":\"template=admin\",\"created\":1572472540,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\"},\"97\":{\"name\":\"FieldtypeCheckbox\",\"title\":\"Checkbox\",\"version\":101,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"28\":{\"name\":\"FieldtypeDatetime\",\"title\":\"Datetime\",\"version\":105,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"29\":{\"name\":\"FieldtypeEmail\",\"title\":\"E-Mail\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"106\":{\"name\":\"FieldtypeFieldsetClose\",\"title\":\"Fieldset (Close)\",\"version\":100,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"105\":{\"name\":\"FieldtypeFieldsetOpen\",\"title\":\"Fieldset (Open)\",\"version\":101,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"107\":{\"name\":\"FieldtypeFieldsetTabOpen\",\"title\":\"Fieldset in Tab (Open)\",\"version\":100,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"6\":{\"name\":\"FieldtypeFile\",\"title\":\"Files\",\"version\":106,\"created\":1572472518,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"89\":{\"name\":\"FieldtypeFloat\",\"title\":\"Float\",\"version\":105,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"57\":{\"name\":\"FieldtypeImage\",\"title\":\"Images\",\"version\":102,\"created\":1572472518,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"84\":{\"name\":\"FieldtypeInteger\",\"title\":\"Integer\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"27\":{\"name\":\"FieldtypeModule\",\"title\":\"Module Reference\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"4\":{\"name\":\"FieldtypePage\",\"title\":\"Page Reference\",\"version\":105,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"111\":{\"name\":\"FieldtypePageTitle\",\"title\":\"Page Title\",\"version\":100,\"singular\":true,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"133\":{\"name\":\"FieldtypePassword\",\"title\":\"Password\",\"version\":101,\"singular\":true,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"3\":{\"name\":\"FieldtypeText\",\"title\":\"Text\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"1\":{\"name\":\"FieldtypeTextarea\",\"title\":\"Textarea\",\"version\":107,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"135\":{\"name\":\"FieldtypeURL\",\"title\":\"URL\",\"version\":101,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"25\":{\"name\":\"InputfieldAsmSelect\",\"title\":\"asmSelect\",\"version\":202,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"131\":{\"name\":\"InputfieldButton\",\"title\":\"Button\",\"version\":100,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"37\":{\"name\":\"InputfieldCheckbox\",\"title\":\"Checkbox\",\"version\":106,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"38\":{\"name\":\"InputfieldCheckboxes\",\"title\":\"Checkboxes\",\"version\":107,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"155\":{\"name\":\"InputfieldCKEditor\",\"title\":\"CKEditor\",\"version\":163,\"installs\":[\"MarkupHTMLPurifier\"],\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"94\":{\"name\":\"InputfieldDatetime\",\"title\":\"Datetime\",\"version\":107,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"80\":{\"name\":\"InputfieldEmail\",\"title\":\"Email\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"78\":{\"name\":\"InputfieldFieldset\",\"title\":\"Fieldset\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"55\":{\"name\":\"InputfieldFile\",\"title\":\"Files\",\"version\":126,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"90\":{\"name\":\"InputfieldFloat\",\"title\":\"Float\",\"version\":103,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"30\":{\"name\":\"InputfieldForm\",\"title\":\"Form\",\"version\":107,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"40\":{\"name\":\"InputfieldHidden\",\"title\":\"Hidden\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"162\":{\"name\":\"InputfieldIcon\",\"title\":\"Icon\",\"version\":2,\"created\":1572472553,\"namespace\":\"ProcessWire\\\\\"},\"56\":{\"name\":\"InputfieldImage\",\"title\":\"Images\",\"version\":123,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"85\":{\"name\":\"InputfieldInteger\",\"title\":\"Integer\",\"version\":104,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"79\":{\"name\":\"InputfieldMarkup\",\"title\":\"Markup\",\"version\":102,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"41\":{\"name\":\"InputfieldName\",\"title\":\"Name\",\"version\":100,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"60\":{\"name\":\"InputfieldPage\",\"title\":\"Page\",\"version\":107,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"15\":{\"name\":\"InputfieldPageListSelect\",\"title\":\"Page List Select\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"137\":{\"name\":\"InputfieldPageListSelectMultiple\",\"title\":\"Page List Select Multiple\",\"version\":102,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"86\":{\"name\":\"InputfieldPageName\",\"title\":\"Page Name\",\"version\":106,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"112\":{\"name\":\"InputfieldPageTitle\",\"title\":\"Page Title\",\"version\":102,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"122\":{\"name\":\"InputfieldPassword\",\"title\":\"Password\",\"version\":102,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"39\":{\"name\":\"InputfieldRadios\",\"title\":\"Radio Buttons\",\"version\":105,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"36\":{\"name\":\"InputfieldSelect\",\"title\":\"Select\",\"version\":102,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"43\":{\"name\":\"InputfieldSelectMultiple\",\"title\":\"Select Multiple\",\"version\":101,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"149\":{\"name\":\"InputfieldSelector\",\"title\":\"Selector\",\"version\":28,\"autoload\":\"template=admin\",\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"addFlag\":32},\"32\":{\"name\":\"InputfieldSubmit\",\"title\":\"Submit\",\"version\":102,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"34\":{\"name\":\"InputfieldText\",\"title\":\"Text\",\"version\":106,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"35\":{\"name\":\"InputfieldTextarea\",\"title\":\"Textarea\",\"version\":103,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"108\":{\"name\":\"InputfieldURL\",\"title\":\"URL\",\"version\":102,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"116\":{\"name\":\"JqueryCore\",\"title\":\"jQuery Core\",\"version\":183,\"singular\":true,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"151\":{\"name\":\"JqueryMagnific\",\"title\":\"jQuery Magnific Popup\",\"version\":1,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"103\":{\"name\":\"JqueryTableSorter\",\"title\":\"jQuery Table Sorter Plugin\",\"version\":221,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"117\":{\"name\":\"JqueryUI\",\"title\":\"jQuery UI\",\"version\":196,\"singular\":true,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"45\":{\"name\":\"JqueryWireTabs\",\"title\":\"jQuery Wire Tabs Plugin\",\"version\":109,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"163\":{\"name\":\"LanguageSupport\",\"title\":\"Languages Support\",\"version\":103,\"installs\":[\"ProcessLanguage\",\"ProcessLanguageTranslator\"],\"autoload\":true,\"singular\":true,\"created\":1572472642,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"addFlag\":32},\"164\":{\"name\":\"ProcessLanguage\",\"title\":\"Languages\",\"version\":103,\"icon\":\"language\",\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"permission\":\"lang-edit\",\"singular\":1,\"created\":1572472642,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"useNavJSON\":true},\"165\":{\"name\":\"ProcessLanguageTranslator\",\"title\":\"Language Translator\",\"version\":101,\"requiresVersions\":{\"LanguageSupport\":[\">=\",0]},\"permission\":\"lang-edit\",\"singular\":1,\"created\":1572472642,\"namespace\":\"ProcessWire\\\\\"},\"67\":{\"name\":\"MarkupAdminDataTable\",\"title\":\"Admin Data Table\",\"version\":107,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"156\":{\"name\":\"MarkupHTMLPurifier\",\"title\":\"HTML Purifier\",\"version\":495,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"113\":{\"name\":\"MarkupPageArray\",\"title\":\"PageArray Markup\",\"version\":100,\"autoload\":true,\"singular\":true,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"98\":{\"name\":\"MarkupPagerNav\",\"title\":\"Pager (Pagination) Navigation\",\"version\":105,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"114\":{\"name\":\"PagePermissions\",\"title\":\"Page Permissions\",\"version\":105,\"autoload\":true,\"singular\":true,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"115\":{\"name\":\"PageRender\",\"title\":\"Page Render\",\"version\":105,\"autoload\":true,\"singular\":true,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"48\":{\"name\":\"ProcessField\",\"title\":\"Fields\",\"version\":113,\"icon\":\"cube\",\"permission\":\"field-admin\",\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"87\":{\"name\":\"ProcessHome\",\"title\":\"Admin Home\",\"version\":101,\"permission\":\"page-view\",\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"76\":{\"name\":\"ProcessList\",\"title\":\"List\",\"version\":101,\"permission\":\"page-view\",\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"161\":{\"name\":\"ProcessLogger\",\"title\":\"Logs\",\"version\":2,\"icon\":\"tree\",\"permission\":\"logs-view\",\"singular\":1,\"created\":1572472553,\"namespace\":\"ProcessWire\\\\\",\"useNavJSON\":true},\"10\":{\"name\":\"ProcessLogin\",\"title\":\"Login\",\"version\":108,\"permission\":\"page-view\",\"created\":1572472518,\"configurable\":4,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"50\":{\"name\":\"ProcessModule\",\"title\":\"Modules\",\"version\":118,\"permission\":\"module-admin\",\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true,\"nav\":[{\"url\":\"?site#tab_site_modules\",\"label\":\"Site\",\"icon\":\"plug\",\"navJSON\":\"navJSON\\/?site=1\"},{\"url\":\"?core#tab_core_modules\",\"label\":\"Core\",\"icon\":\"plug\",\"navJSON\":\"navJSON\\/?core=1\"},{\"url\":\"?configurable#tab_configurable_modules\",\"label\":\"Configure\",\"icon\":\"gear\",\"navJSON\":\"navJSON\\/?configurable=1\"},{\"url\":\"?install#tab_install_modules\",\"label\":\"Install\",\"icon\":\"sign-in\",\"navJSON\":\"navJSON\\/?install=1\"},{\"url\":\"?new#tab_new_modules\",\"label\":\"New\",\"icon\":\"plus\"},{\"url\":\"?reset=1\",\"label\":\"Refresh\",\"icon\":\"refresh\"}]},\"17\":{\"name\":\"ProcessPageAdd\",\"title\":\"Page Add\",\"version\":108,\"icon\":\"plus-circle\",\"permission\":\"page-edit\",\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true},\"7\":{\"name\":\"ProcessPageEdit\",\"title\":\"Page Edit\",\"version\":109,\"icon\":\"edit\",\"permission\":\"page-edit\",\"singular\":1,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true},\"129\":{\"name\":\"ProcessPageEditImageSelect\",\"title\":\"Page Edit Image\",\"version\":120,\"permission\":\"page-edit\",\"singular\":1,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"121\":{\"name\":\"ProcessPageEditLink\",\"title\":\"Page Edit Link\",\"version\":108,\"icon\":\"link\",\"permission\":\"page-edit\",\"singular\":1,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"12\":{\"name\":\"ProcessPageList\",\"title\":\"Page List\",\"version\":122,\"icon\":\"sitemap\",\"permission\":\"page-edit\",\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true},\"150\":{\"name\":\"ProcessPageLister\",\"title\":\"Lister\",\"version\":26,\"icon\":\"search\",\"permission\":\"page-lister\",\"created\":1572472518,\"configurable\":true,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"104\":{\"name\":\"ProcessPageSearch\",\"title\":\"Page Search\",\"version\":106,\"permission\":\"page-edit\",\"singular\":1,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"14\":{\"name\":\"ProcessPageSort\",\"title\":\"Page Sort and Move\",\"version\":100,\"permission\":\"page-edit\",\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"109\":{\"name\":\"ProcessPageTrash\",\"title\":\"Page Trash\",\"version\":103,\"singular\":1,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"134\":{\"name\":\"ProcessPageType\",\"title\":\"Page Type\",\"version\":101,\"singular\":1,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true,\"addFlag\":32},\"83\":{\"name\":\"ProcessPageView\",\"title\":\"Page View\",\"version\":104,\"permission\":\"page-view\",\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"136\":{\"name\":\"ProcessPermission\",\"title\":\"Permissions\",\"version\":101,\"icon\":\"gear\",\"permission\":\"permission-admin\",\"singular\":1,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true},\"138\":{\"name\":\"ProcessProfile\",\"title\":\"User Profile\",\"version\":104,\"permission\":\"profile-edit\",\"singular\":1,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"159\":{\"name\":\"ProcessRecentPages\",\"title\":\"Recent Pages\",\"version\":2,\"icon\":\"clock-o\",\"permission\":\"page-edit-recent\",\"singular\":1,\"created\":1572472540,\"namespace\":\"ProcessWire\\\\\",\"useNavJSON\":true,\"nav\":[{\"url\":\"?edited=1\",\"label\":\"Edited\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?edited=1\"},{\"url\":\"?added=1\",\"label\":\"Created\",\"icon\":\"users\",\"navJSON\":\"navJSON\\/?added=1\"},{\"url\":\"?edited=1&me=1\",\"label\":\"Edited by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?edited=1&me=1\"},{\"url\":\"?added=1&me=1\",\"label\":\"Created by me\",\"icon\":\"user\",\"navJSON\":\"navJSON\\/?added=1&me=1\"},{\"url\":\"another\\/\",\"label\":\"Add another\",\"icon\":\"plus-circle\",\"navJSON\":\"anotherNavJSON\\/\"}]},\"68\":{\"name\":\"ProcessRole\",\"title\":\"Roles\",\"version\":104,\"icon\":\"gears\",\"permission\":\"role-admin\",\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true},\"47\":{\"name\":\"ProcessTemplate\",\"title\":\"Templates\",\"version\":114,\"icon\":\"cubes\",\"permission\":\"template-admin\",\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true},\"66\":{\"name\":\"ProcessUser\",\"title\":\"Users\",\"version\":107,\"icon\":\"group\",\"permission\":\"user-admin\",\"created\":1572472518,\"configurable\":\"ProcessUserConfig.php\",\"namespace\":\"ProcessWire\\\\\",\"permanent\":true,\"useNavJSON\":true},\"125\":{\"name\":\"SessionLoginThrottle\",\"title\":\"Session Login Throttle\",\"version\":103,\"autoload\":\"function\",\"singular\":true,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\"},\"139\":{\"name\":\"SystemUpdater\",\"title\":\"System Updater\",\"version\":17,\"singular\":true,\"created\":1572472518,\"configurable\":3,\"namespace\":\"ProcessWire\\\\\",\"permanent\":true},\"61\":{\"name\":\"TextformatterEntities\",\"title\":\"HTML Entity Encoder (htmlspecialchars)\",\"version\":100,\"created\":1572472518,\"namespace\":\"ProcessWire\\\\\"},\"166\":{\"name\":\"ProcessWireUpgrade\",\"title\":\"Upgrades\",\"version\":7,\"icon\":\"coffee\",\"requiresVersions\":{\"ProcessWire\":[\">=\",\"2.5.20\"]},\"installs\":[\"ProcessWireUpgradeCheck\"],\"singular\":true,\"created\":1587389402,\"namespace\":\"\\\\\"},\"167\":{\"name\":\"ProcessWireUpgradeCheck\",\"title\":\"Upgrades Checker\",\"version\":7,\"icon\":\"coffee\",\"autoload\":\"template=admin\",\"singular\":true,\"created\":1587389403,\"configurable\":\"ProcessWireUpgradeCheck.config.php\",\"namespace\":\"\\\\\"}}','2010-04-08 03:10:01'),('ModulesVerbose.info','{\"148\":{\"summary\":\"Minimal admin theme that supports all ProcessWire features.\",\"core\":true,\"versionStr\":\"0.1.4\"},\"160\":{\"summary\":\"Uikit v3 admin theme\",\"core\":true,\"versionStr\":\"0.3.0\"},\"97\":{\"summary\":\"This Fieldtype stores an ON\\/OFF toggle via a single checkbox. The ON value is 1 and OFF value is 0.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"28\":{\"summary\":\"Field that stores a date and optionally time\",\"core\":true,\"versionStr\":\"1.0.5\"},\"29\":{\"summary\":\"Field that stores an e-mail address\",\"core\":true,\"versionStr\":\"1.0.1\"},\"106\":{\"summary\":\"Close a fieldset opened by FieldsetOpen. \",\"core\":true,\"versionStr\":\"1.0.0\"},\"105\":{\"summary\":\"Open a fieldset to group fields. Should be followed by a Fieldset (Close) after one or more fields.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"107\":{\"summary\":\"Open a fieldset to group fields. Same as Fieldset (Open) except that it displays in a tab instead.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"6\":{\"summary\":\"Field that stores one or more files\",\"core\":true,\"versionStr\":\"1.0.6\"},\"89\":{\"summary\":\"Field that stores a floating point (decimal) number\",\"core\":true,\"versionStr\":\"1.0.5\"},\"57\":{\"summary\":\"Field that stores one or more GIF, JPG, or PNG images\",\"core\":true,\"versionStr\":\"1.0.2\"},\"84\":{\"summary\":\"Field that stores an integer\",\"core\":true,\"versionStr\":\"1.0.1\"},\"27\":{\"summary\":\"Field that stores a reference to another module\",\"core\":true,\"versionStr\":\"1.0.1\"},\"4\":{\"summary\":\"Field that stores one or more references to ProcessWire pages\",\"core\":true,\"versionStr\":\"1.0.5\"},\"111\":{\"summary\":\"Field that stores a page title\",\"core\":true,\"versionStr\":\"1.0.0\"},\"133\":{\"summary\":\"Field that stores a hashed and salted password\",\"core\":true,\"versionStr\":\"1.0.1\"},\"3\":{\"summary\":\"Field that stores a single line of text\",\"core\":true,\"versionStr\":\"1.0.1\"},\"1\":{\"summary\":\"Field that stores multiple lines of text\",\"core\":true,\"versionStr\":\"1.0.7\"},\"135\":{\"summary\":\"Field that stores a URL\",\"core\":true,\"versionStr\":\"1.0.1\"},\"25\":{\"summary\":\"Multiple selection, progressive enhancement to select multiple\",\"core\":true,\"versionStr\":\"2.0.2\"},\"131\":{\"summary\":\"Form button element that you can optionally pass an href attribute to.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"37\":{\"summary\":\"Single checkbox toggle\",\"core\":true,\"versionStr\":\"1.0.6\"},\"38\":{\"summary\":\"Multiple checkbox toggles\",\"core\":true,\"versionStr\":\"1.0.7\"},\"155\":{\"summary\":\"CKEditor textarea rich text editor.\",\"core\":true,\"versionStr\":\"1.6.3\"},\"94\":{\"summary\":\"Inputfield that accepts date and optionally time\",\"core\":true,\"versionStr\":\"1.0.7\"},\"80\":{\"summary\":\"E-Mail address in valid format\",\"core\":true,\"versionStr\":\"1.0.1\"},\"78\":{\"summary\":\"Groups one or more fields together in a container\",\"core\":true,\"versionStr\":\"1.0.1\"},\"55\":{\"summary\":\"One or more file uploads (sortable)\",\"core\":true,\"versionStr\":\"1.2.6\"},\"90\":{\"summary\":\"Floating point number with precision\",\"core\":true,\"versionStr\":\"1.0.3\"},\"30\":{\"summary\":\"Contains one or more fields in a form\",\"core\":true,\"versionStr\":\"1.0.7\"},\"40\":{\"summary\":\"Hidden value in a form\",\"core\":true,\"versionStr\":\"1.0.1\"},\"162\":{\"summary\":\"Select an icon\",\"core\":true,\"versionStr\":\"0.0.2\"},\"56\":{\"summary\":\"One or more image uploads (sortable)\",\"core\":true,\"versionStr\":\"1.2.3\"},\"85\":{\"summary\":\"Integer (positive or negative)\",\"core\":true,\"versionStr\":\"1.0.4\"},\"79\":{\"summary\":\"Contains any other markup and optionally child Inputfields\",\"core\":true,\"versionStr\":\"1.0.2\"},\"41\":{\"summary\":\"Text input validated as a ProcessWire name field\",\"core\":true,\"versionStr\":\"1.0.0\"},\"60\":{\"summary\":\"Select one or more pages\",\"core\":true,\"versionStr\":\"1.0.7\"},\"15\":{\"summary\":\"Selection of a single page from a ProcessWire page tree list\",\"core\":true,\"versionStr\":\"1.0.1\"},\"137\":{\"summary\":\"Selection of multiple pages from a ProcessWire page tree list\",\"core\":true,\"versionStr\":\"1.0.2\"},\"86\":{\"summary\":\"Text input validated as a ProcessWire Page name field\",\"core\":true,\"versionStr\":\"1.0.6\"},\"112\":{\"summary\":\"Handles input of Page Title and auto-generation of Page Name (when name is blank)\",\"core\":true,\"versionStr\":\"1.0.2\"},\"122\":{\"summary\":\"Password input with confirmation field that doesn&#039;t ever echo the input back.\",\"core\":true,\"versionStr\":\"1.0.2\"},\"39\":{\"summary\":\"Radio buttons for selection of a single item\",\"core\":true,\"versionStr\":\"1.0.5\"},\"36\":{\"summary\":\"Selection of a single value from a select pulldown\",\"core\":true,\"versionStr\":\"1.0.2\"},\"43\":{\"summary\":\"Select multiple items from a list\",\"core\":true,\"versionStr\":\"1.0.1\"},\"149\":{\"summary\":\"Build a page finding selector visually.\",\"author\":\"Avoine + ProcessWire\",\"core\":true,\"versionStr\":\"0.2.8\"},\"32\":{\"summary\":\"Form submit button\",\"core\":true,\"versionStr\":\"1.0.2\"},\"34\":{\"summary\":\"Single line of text\",\"core\":true,\"versionStr\":\"1.0.6\"},\"35\":{\"summary\":\"Multiple lines of text\",\"core\":true,\"versionStr\":\"1.0.3\"},\"108\":{\"summary\":\"URL in valid format\",\"core\":true,\"versionStr\":\"1.0.2\"},\"116\":{\"summary\":\"jQuery Core as required by ProcessWire Admin and plugins\",\"href\":\"http:\\/\\/jquery.com\",\"core\":true,\"versionStr\":\"1.8.3\"},\"151\":{\"summary\":\"Provides lightbox capability for image galleries. Replacement for FancyBox. Uses Magnific Popup by @dimsemenov.\",\"href\":\"http:\\/\\/dimsemenov.com\\/plugins\\/magnific-popup\\/\",\"core\":true,\"versionStr\":\"0.0.1\"},\"103\":{\"summary\":\"Provides a jQuery plugin for sorting tables.\",\"href\":\"http:\\/\\/mottie.github.io\\/tablesorter\\/\",\"core\":true,\"versionStr\":\"2.2.1\"},\"117\":{\"summary\":\"jQuery UI as required by ProcessWire and plugins\",\"href\":\"http:\\/\\/ui.jquery.com\",\"core\":true,\"versionStr\":\"1.9.6\"},\"45\":{\"summary\":\"Provides a jQuery plugin for generating tabs in ProcessWire.\",\"core\":true,\"versionStr\":\"1.0.9\"},\"163\":{\"summary\":\"ProcessWire multi-language support.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"1.0.3\"},\"164\":{\"summary\":\"Manage system languages\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"1.0.3\",\"permissions\":{\"lang-edit\":\"Administer languages and static translation files\"}},\"165\":{\"summary\":\"Provides language translation capabilities for ProcessWire core and modules.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"1.0.1\"},\"67\":{\"summary\":\"Generates markup for data tables used by ProcessWire admin\",\"core\":true,\"versionStr\":\"1.0.7\"},\"156\":{\"summary\":\"Front-end to the HTML Purifier library.\",\"core\":true,\"versionStr\":\"4.9.5\"},\"113\":{\"summary\":\"Adds renderPager() method to all PaginatedArray types, for easy pagination output. Plus a render() method to PageArray instances.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"98\":{\"summary\":\"Generates markup for pagination navigation\",\"core\":true,\"versionStr\":\"1.0.5\"},\"114\":{\"summary\":\"Adds various permission methods to Page objects that are used by Process modules.\",\"core\":true,\"versionStr\":\"1.0.5\"},\"115\":{\"summary\":\"Adds a render method to Page and caches page output.\",\"core\":true,\"versionStr\":\"1.0.5\"},\"48\":{\"summary\":\"Edit individual fields that hold page data\",\"core\":true,\"versionStr\":\"1.1.3\",\"searchable\":\"fields\"},\"87\":{\"summary\":\"Acts as a placeholder Process for the admin root. Ensures proper flow control after login.\",\"core\":true,\"versionStr\":\"1.0.1\"},\"76\":{\"summary\":\"Lists the Process assigned to each child page of the current\",\"core\":true,\"versionStr\":\"1.0.1\"},\"161\":{\"summary\":\"View and manage system logs.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"0.0.2\",\"permissions\":{\"logs-view\":\"Can view system logs\",\"logs-edit\":\"Can manage system logs\"},\"page\":{\"name\":\"logs\",\"parent\":\"setup\",\"title\":\"Logs\"}},\"10\":{\"summary\":\"Login to ProcessWire\",\"core\":true,\"versionStr\":\"1.0.8\"},\"50\":{\"summary\":\"List, edit or install\\/uninstall modules\",\"core\":true,\"versionStr\":\"1.1.8\"},\"17\":{\"summary\":\"Add a new page\",\"core\":true,\"versionStr\":\"1.0.8\"},\"7\":{\"summary\":\"Edit a Page\",\"core\":true,\"versionStr\":\"1.0.9\"},\"129\":{\"summary\":\"Provides image manipulation functions for image fields and rich text editors.\",\"core\":true,\"versionStr\":\"1.2.0\"},\"121\":{\"summary\":\"Provides a link capability as used by some Fieldtype modules (like rich text editors).\",\"core\":true,\"versionStr\":\"1.0.8\"},\"12\":{\"summary\":\"List pages in a hierarchical tree structure\",\"core\":true,\"versionStr\":\"1.2.2\"},\"150\":{\"summary\":\"Admin tool for finding and listing pages by any property.\",\"author\":\"Ryan Cramer\",\"core\":true,\"versionStr\":\"0.2.6\",\"permissions\":{\"page-lister\":\"Use Page Lister\"}},\"104\":{\"summary\":\"Provides a page search engine for admin use.\",\"core\":true,\"versionStr\":\"1.0.6\"},\"14\":{\"summary\":\"Handles page sorting and moving for PageList\",\"core\":true,\"versionStr\":\"1.0.0\"},\"109\":{\"summary\":\"Handles emptying of Page trash\",\"core\":true,\"versionStr\":\"1.0.3\"},\"134\":{\"summary\":\"List, Edit and Add pages of a specific type\",\"core\":true,\"versionStr\":\"1.0.1\"},\"83\":{\"summary\":\"All page views are routed through this Process\",\"core\":true,\"versionStr\":\"1.0.4\"},\"136\":{\"summary\":\"Manage system permissions\",\"core\":true,\"versionStr\":\"1.0.1\"},\"138\":{\"summary\":\"Enables user to change their password, email address and other settings that you define.\",\"core\":true,\"versionStr\":\"1.0.4\"},\"159\":{\"summary\":\"Shows a list of recently edited pages in your admin.\",\"author\":\"Ryan Cramer\",\"href\":\"http:\\/\\/modules.processwire.com\\/\",\"core\":true,\"versionStr\":\"0.0.2\",\"permissions\":{\"page-edit-recent\":\"Can see recently edited pages\"},\"page\":{\"name\":\"recent-pages\",\"parent\":\"page\",\"title\":\"Recent\"}},\"68\":{\"summary\":\"Manage user roles and what permissions are attached\",\"core\":true,\"versionStr\":\"1.0.4\"},\"47\":{\"summary\":\"List and edit the templates that control page output\",\"core\":true,\"versionStr\":\"1.1.4\",\"searchable\":\"templates\"},\"66\":{\"summary\":\"Manage system users\",\"core\":true,\"versionStr\":\"1.0.7\",\"searchable\":\"users\"},\"125\":{\"summary\":\"Throttles login attempts to help prevent dictionary attacks.\",\"core\":true,\"versionStr\":\"1.0.3\"},\"139\":{\"summary\":\"Manages system versions and upgrades.\",\"core\":true,\"versionStr\":\"0.1.7\"},\"61\":{\"summary\":\"Entity encode ampersands, quotes (single and double) and greater-than\\/less-than signs using htmlspecialchars(str, ENT_QUOTES). It is recommended that you use this on all text\\/textarea fields except those using a rich text editor or a markup language like Markdown.\",\"core\":true,\"versionStr\":\"1.0.0\"},\"166\":{\"summary\":\"Tool that helps you identify and install core and module upgrades.\",\"author\":\"Ryan Cramer\",\"versionStr\":\"0.0.7\"},\"167\":{\"summary\":\"Automatically checks for core and installed module upgrades at routine intervals.\",\"author\":\"Ryan Cramer\",\"versionStr\":\"0.0.7\"}}','2010-04-08 03:10:01'),('Permissions.names','{\"lang-edit\":1015,\"logs-edit\":1014,\"logs-view\":1013,\"page-delete\":34,\"page-edit\":32,\"page-edit-recent\":1011,\"page-lister\":1006,\"page-lock\":54,\"page-move\":35,\"page-sort\":50,\"page-template\":51,\"page-view\":36,\"profile-edit\":53,\"user-admin\":52}','2010-04-08 03:10:10'),('FileCompiler__3579327fd3f4e787a1da3ac9b36a94b8','{\"source\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/templates\\/home.php\",\"hash\":\"b7f85fedd6b16c7d01d610284b4613e0\",\"size\":37,\"time\":1572472368,\"ns\":\"\\\\\"},\"target\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/templates\\/home.php\",\"hash\":\"8c53e853b3ed1bf662e66630c740897b\",\"size\":213,\"time\":1572472368}}','2010-04-08 03:10:10'),('FileCompiler__249225710578486943db9b574ca774ad','{\"source\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/templates\\/basic-page.php\",\"hash\":\"db5828c7dd5a5123c7963c0fb016f7a7\",\"size\":419,\"time\":1572472368,\"ns\":\"\\\\\"},\"target\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/templates\\/basic-page.php\",\"hash\":\"db5828c7dd5a5123c7963c0fb016f7a7\",\"size\":419,\"time\":1572472368}}','2010-04-08 03:10:10'),('FileCompiler__a3a59ddf87d0ca43842bf7baf8deb65c','{\"source\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgrade.module\",\"hash\":\"66cc6ed58e83f659bc4a51665b4d2d83\",\"size\":26751,\"time\":1587389400,\"ns\":\"\\\\\"},\"target\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgrade.module\",\"hash\":\"e755d22d24df133c8b6ce26f22e281c1\",\"size\":27050,\"time\":1587389400}}','2010-04-08 03:10:10'),('FileCompiler__def2a93c58692612ba73667b943d12cc','{\"source\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgradeCheck.module\",\"hash\":\"1f30f3a328cbd2d9b9ceeb9e7cb0ab9e\",\"size\":11162,\"time\":1587389400,\"ns\":\"\\\\\"},\"target\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgradeCheck.module\",\"hash\":\"967631030b36c79030d70a146b00afd5\",\"size\":11253,\"time\":1587389400}}','2010-04-08 03:10:10'),('FileCompiler__7826df1f1c6d83e6ec3a2f1c66c354af','{\"source\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgradeCheck.config.php\",\"hash\":\"c3c743773b0bce19a80fe6d3a7a8f516\",\"size\":622,\"time\":1587389400,\"ns\":\"\\\\\"},\"target\":{\"file\":\"P:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgradeCheck.config.php\",\"hash\":\"2a9c49f29d6273cd1cf98c764aae5530\",\"size\":635,\"time\":1587389400}}','2010-04-08 03:10:10'),('ModulesVersions.info','{\"25\":121,\"155\":161,\"56\":122,\"156\":492,\"150\":24,\"94\":106}','2010-04-08 03:10:01'),('FileCompiler__e54f35fe33027ccec3607cd32ad5b300','{\"source\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/ready.php\",\"hash\":\"d9031c08b9da484fb6ab6eb84f2a8c60\",\"size\":1219,\"time\":1595255398,\"ns\":\"ProcessWire\"},\"target\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/ready.php\",\"hash\":\"d9031c08b9da484fb6ab6eb84f2a8c60\",\"size\":1219,\"time\":1595255398}}','2010-04-08 03:10:10'),('FileCompiler__52de64db0471fe74e67935ea689bf852','{\"source\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/templates\\/home.php\",\"hash\":\"b7f85fedd6b16c7d01d610284b4613e0\",\"size\":37,\"time\":1572472368,\"ns\":\"\\\\\"},\"target\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/templates\\/home.php\",\"hash\":\"8c53e853b3ed1bf662e66630c740897b\",\"size\":213,\"time\":1572472368}}','2010-04-08 03:10:10'),('FileCompiler__430b3950128dbaf83b3b8d55a4f8f9de','{\"source\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/templates\\/basic-page.php\",\"hash\":\"db5828c7dd5a5123c7963c0fb016f7a7\",\"size\":419,\"time\":1572472368,\"ns\":\"\\\\\"},\"target\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/templates\\/basic-page.php\",\"hash\":\"db5828c7dd5a5123c7963c0fb016f7a7\",\"size\":419,\"time\":1572472368}}','2010-04-08 03:10:10'),('FileCompiler__030ab4f8edcd0b190c1ba545559c0ebf','{\"source\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgradeCheck.module\",\"hash\":\"1f30f3a328cbd2d9b9ceeb9e7cb0ab9e\",\"size\":11162,\"time\":1587389400,\"ns\":\"\\\\\"},\"target\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgradeCheck.module\",\"hash\":\"967631030b36c79030d70a146b00afd5\",\"size\":11253,\"time\":1587389400}}','2010-04-08 03:10:10'),('FileCompiler__b052cbe7b644c5a90da8a3981eb6db23','{\"source\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgradeCheck.config.php\",\"hash\":\"c3c743773b0bce19a80fe6d3a7a8f516\",\"size\":622,\"time\":1587389400,\"ns\":\"\\\\\"},\"target\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgradeCheck.config.php\",\"hash\":\"2a9c49f29d6273cd1cf98c764aae5530\",\"size\":635,\"time\":1587389400}}','2010-04-08 03:10:10'),('FileCompiler__f2ab5bda2f4098220ddb5ac92bb07307','{\"source\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/templates\\/admin.php\",\"hash\":\"9636f854995462a4cb877cb1204bc2fe\",\"size\":467,\"time\":1572472368,\"ns\":\"ProcessWire\"},\"target\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/templates\\/admin.php\",\"hash\":\"9636f854995462a4cb877cb1204bc2fe\",\"size\":467,\"time\":1572472368}}','2010-04-08 03:10:10'),('FileCompiler__8331a48a1dedd17718c94e0aeb5255a9','{\"source\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgrade.module\",\"hash\":\"66cc6ed58e83f659bc4a51665b4d2d83\",\"size\":26751,\"time\":1587389400,\"ns\":\"\\\\\"},\"target\":{\"file\":\"D:\\/htdocs\\/pw-lang-de-new\\/site\\/assets\\/cache\\/FileCompiler\\/site\\/modules\\/ProcessWireUpgrade\\/ProcessWireUpgrade.module\",\"hash\":\"e755d22d24df133c8b6ce26f22e281c1\",\"size\":27050,\"time\":1587389400}}','2010-04-08 03:10:10');
/*!40000 ALTER TABLE `caches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `caches` with 21 row(s)
--

--
-- Table structure for table `field_admin_theme`
--

DROP TABLE IF EXISTS `field_admin_theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_admin_theme` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_admin_theme`
--

LOCK TABLES `field_admin_theme` WRITE;
/*!40000 ALTER TABLE `field_admin_theme` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `field_admin_theme` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_admin_theme` with 0 row(s)
--

--
-- Table structure for table `field_email`
--

DROP TABLE IF EXISTS `field_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_email` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_email`
--

LOCK TABLES `field_email` WRITE;
/*!40000 ALTER TABLE `field_email` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_email` VALUES (41,'admin@example.com');
/*!40000 ALTER TABLE `field_email` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_email` with 1 row(s)
--

--
-- Table structure for table `field_language`
--

DROP TABLE IF EXISTS `field_language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_language` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_language`
--

LOCK TABLES `field_language` WRITE;
/*!40000 ALTER TABLE `field_language` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_language` VALUES (40,1017,0),(41,1017,0);
/*!40000 ALTER TABLE `field_language` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_language` with 2 row(s)
--

--
-- Table structure for table `field_language_files`
--

DROP TABLE IF EXISTS `field_language_files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_language_files` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(250) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `filedata` mediumtext,
  `filesize` int(11) DEFAULT NULL,
  `created_users_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `filesize` (`filesize`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `filedata` (`filedata`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_language_files`
--

LOCK TABLES `field_language_files` WRITE;
/*!40000 ALTER TABLE `field_language_files` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_language_files` VALUES (1019,'wire--core--processwire-php.json',184,'[\"\"]','2020-04-20 15:59:02','2020-04-20 15:59:02','',NULL,0,0),(1019,'wire--modules--pagepathhistory-module.json',185,'[\"\"]','2020-04-20 15:59:03','2020-04-20 15:59:03','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypetoggle-module.json',186,'[\"\"]','2020-04-20 15:59:03','2020-04-20 15:59:03','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldtoggle--inputfieldtoggle-module.json',187,'[\"\"]','2020-04-20 15:59:03','2020-04-20 15:59:03','',NULL,0,0),(1019,'wire--modules--system--systemupdater--systemupdaterchecks-php.json',188,'[\"\"]','2020-04-20 15:59:03','2020-04-20 15:59:03','',NULL,0,0),(1019,'wire--templates-admin--topnav-inc.json',182,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--core--pagesnames-php.json',183,'[\"\"]','2020-04-20 15:59:02','2020-04-20 15:59:02','',NULL,0,0),(1019,'wire--templates-admin--debug-inc.json',180,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--templates-admin--default-php.json',181,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--textformatter--textformattermarkdownextra--parsedown--parsedown-php.json',178,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--textformatter--textformattersmartypants--textformattersmartypants-module.json',179,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--textformatter--textformattermarkdownextra--textformattermarkdownextra-module.json',177,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--system--systemupdater--systemupdater-module.json',175,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--textformatter--textformatterentities-module.json',176,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--system--systemnotifications--systemnotifications-module.json',173,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--system--systemnotifications--systemnotificationsconfig-php.json',174,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--session--sessionloginthrottle--sessionloginthrottle-module.json',172,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--session--sessionhandlerdb--sessionhandlerdb-module.json',171,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processuser--processuserconfig-php.json',169,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--session--sessionhandlerdb--processsessiondb-module.json',170,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processuser--processuser-module.json',168,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processrole--processrole-module.json',165,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processtemplate--processtemplate-module.json',166,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processrecentpages--processrecentpages-module.json',164,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processtemplate--processtemplateexportimport-php.json',167,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagesearch--processpagesearchlive-php.json',159,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagesexportimport--processpagesexportimport-module.json',160,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagetype--processpagetype-module.json',161,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpermission--processpermission-module.json',162,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processprofile--processprofile-module.json',163,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagesearch--processpagesearch-module.json',158,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagelister--processpagelister-module.json',156,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagelister--processpagelisterbookmarks-php.json',157,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagelist--processpagelistrender-php.json',154,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagelist--processpagelistrenderjson-php.json',155,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagelist--processpagelist-module.json',152,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagelist--processpagelistactions-php.json',153,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processmodule--processmoduleinstall-php.json',146,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpageadd--processpageadd-module.json',147,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpageedit--pagebookmarks-php.json',148,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpageedit--processpageedit-module.json',149,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpageeditimageselect--processpageeditimageselect-module.json',150,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpageeditlink--processpageeditlink-module.json',151,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processmodule--processmodule-module.json',145,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processlogin--processlogin-module.json',144,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagetrash-module.json',138,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpageview-module.json',139,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processcommentsmanager--processcommentsmanager-module.json',140,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processfield--processfield-module.json',141,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processfield--processfieldexportimport-php.json',142,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processlogger--processlogger-module.json',143,'[\"\"]','2019-10-30 23:19:00','2019-10-30 23:19:00','',NULL,0,0),(1019,'wire--modules--process--processpagesort-module.json',137,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--process--processpageclone-module.json',136,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--process--processlist-module.json',135,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--process--processhome-module.json',134,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--process--processforgotpassword-module.json',133,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--page--pagefrontedit--pagefronteditconfig-php.json',132,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--page--pagefrontedit--pagefrontedit-module.json',131,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--markup--markuppagernav--markuppagernav-module.json',130,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--languagesupport--processlanguage-module.json',128,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--markup--markuppagefields-module.json',129,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--languagesupport--languagetranslator-php.json',127,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--languagesupport--languagesupportpagenames-module.json',125,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--languagesupport--languagetabs-module.json',126,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--languagesupport--languagesupportinstall-php.json',124,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--languagesupport--languagesupportfields-module.json',123,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--jquery--jqueryui--jqueryui-module.json',119,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--languagesupport--languagesupport-module.json',122,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--languagesupport--languageparser-php.json',121,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--jquery--jquerywiretabs--jquerywiretabs-module.json',120,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldsubmit--inputfieldsubmit-module.json',118,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldselector--inputfieldselector-module.json',117,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldradios--inputfieldradios-module.json',116,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpassword--inputfieldpassword-module.json',115,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpagetitle--inputfieldpagetitle-module.json',114,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpagetable--inputfieldpagetableajax-php.json',113,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpagetable--inputfieldpagetable-module.json',112,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpagename--inputfieldpagename-module.json',111,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpagelistselect--inputfieldpagelistselectmultiple-module.json',110,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpagelistselect--inputfieldpagelistselect-module.json',109,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpageautocomplete--inputfieldpageautocomplete-module.json',108,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldimage--inputfieldimage-module.json',106,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldpage--inputfieldpage-module.json',107,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldfile--inputfieldfile-module.json',104,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldicon--inputfieldicon-module.json',105,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldckeditor--inputfieldckeditor-module.json',102,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfielddatetime--inputfielddatetime-module.json',103,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldasmselect--inputfieldasmselect-module.json',100,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldcheckboxes--inputfieldcheckboxes-module.json',101,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldurl-module.json',99,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldtextarea-module.json',98,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldtext-module.json',97,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldfloat-module.json',89,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldform-module.json',90,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldhidden-module.json',91,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldinteger-module.json',92,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldmarkup-module.json',93,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldname-module.json',94,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldselect-module.json',95,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldselectmultiple-module.json',96,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldbutton-module.json',85,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldcheckbox-module.json',86,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldemail-module.json',87,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--inputfield--inputfieldfieldset-module.json',88,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--image--imagesizerengineimagick--imagesizerengineimagick-module.json',84,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtyperepeater--fieldtypefieldsetpage-module.json',80,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtyperepeater--fieldtyperepeater-module.json',81,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtyperepeater--inputfieldrepeater-module.json',82,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--image--imagesizerengineanimatedgif--imagesizerengineanimatedgif-module.json',83,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtyperepeater--config-php.json',78,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtyperepeater--fieldsetpageinstructions-php.json',79,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypeoptions--selectableoptionconfig-php.json',76,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypeoptions--selectableoptionmanager-php.json',77,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypeoptions--fieldtypeoptions-module.json',75,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypecomments--inputfieldcommentsadmin-module.json',74,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypecomments--fieldtypecomments-module.json',73,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypecomments--commentstars-php.json',72,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypecomments--commentnotifications-php.json',71,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypecomments--commentlist-php.json',70,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypecomments--commentform-php.json',69,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypeurl-module.json',67,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypecomments--commentfilterakismet-module.json',68,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypetextareahelper-php.json',66,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypepagetable-module.json',63,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypetext-module.json',65,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypeselector-module.json',64,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypepage-module.json',62,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypemodule-module.json',61,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypeinteger-module.json',60,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypedatetime-module.json',56,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypefieldsettabopen-module.json',57,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypefile-module.json',58,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--fieldtype--fieldtypefloat-module.json',59,'[\"\"]','2019-10-30 23:18:59','2019-10-30 23:18:59','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemeuikit--_sidenav-masthead-php.json',55,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemeuikit--_masthead-php.json',54,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemeuikit--_footer-php.json',53,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemeuikit--config-php.json',52,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemeuikit--adminthemeuikit-module.json',51,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemereno--adminthemerenohelpers-php.json',49,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemereno--debug-inc.json',50,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemedefault--adminthemedefaulthelpers-php.json',46,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemereno--adminthemereno-module.json',48,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemedefault--default-php.json',47,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--admintheme--adminthemedefault--adminthemedefault-module.json',45,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--pagerender-module.json',44,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--pagepaths-module.json',43,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--modules--filecompilertags-module.json',42,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--wireupload-php.json',41,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--wiretexttools-php.json',40,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--wireshutdown-php.json',39,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--wirehttp-php.json',38,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--wiredatetime-php.json',37,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--tfa-php.json',34,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--wire-php.json',35,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--wirecache-php.json',36,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--templatefile-php.json',33,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--session-php.json',31,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--sessioncsrf-php.json',32,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--sanitizer-php.json',30,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--processcontroller-php.json',29,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--process-php.json',28,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--permissions-php.json',27,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--password-php.json',26,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--paginatedarray-php.json',25,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--pagesexportimport-php.json',24,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--pageseditor-php.json',23,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--pageimage-php.json',22,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--modulesduplicates-php.json',21,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--modules-php.json',20,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--markupqa-php.json',19,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--languagefunctions-php.json',18,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--interfaces-php.json',17,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--inputfieldwrapper-php.json',16,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--inputfield-php.json',15,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--imagesizerenginegd-php.json',14,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--imagesizerengine-php.json',13,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--functions-php.json',12,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--filevalidatormodule-php.json',11,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--filecompilermodule-php.json',10,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--filecompiler-php.json',9,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--fieldtypemulti-php.json',8,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--fieldtype-php.json',7,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--fieldselectorinfo-php.json',6,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--fields-php.json',5,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--adminthemeframework-php.json',2,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--fieldgroups-php.json',4,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--field-php.json',3,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--admintheme-php.json',1,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0),(1019,'wire--core--admin-php.json',0,'[\"\"]','2019-10-30 23:18:58','2019-10-30 23:18:58','',NULL,0,0);
/*!40000 ALTER TABLE `field_language_files` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_language_files` with 189 row(s)
--

--
-- Table structure for table `field_language_files_site`
--

DROP TABLE IF EXISTS `field_language_files_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_language_files_site` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` varchar(250) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  `description` text NOT NULL,
  `modified` datetime DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `filedata` mediumtext,
  `filesize` int(11) DEFAULT NULL,
  `created_users_id` int(10) unsigned NOT NULL DEFAULT '0',
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `filesize` (`filesize`),
  FULLTEXT KEY `description` (`description`),
  FULLTEXT KEY `filedata` (`filedata`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_language_files_site`
--

LOCK TABLES `field_language_files_site` WRITE;
/*!40000 ALTER TABLE `field_language_files_site` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_language_files_site` VALUES (1019,'site--modules--processwireupgrade--processwireupgradecheck-config-php.json',1,'[\"\"]','2020-04-20 16:13:33','2020-04-20 16:13:33','',NULL,0,0),(1019,'site--modules--processwireupgrade--processwireupgrade-module.json',0,'[\"\"]','2020-04-20 16:13:33','2020-04-20 16:13:33','',NULL,0,0),(1019,'site--modules--processwireupgrade--processwireupgradecheck-module.json',2,'[\"\"]','2020-04-20 16:13:33','2020-04-20 16:13:33','',NULL,0,0);
/*!40000 ALTER TABLE `field_language_files_site` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_language_files_site` with 3 row(s)
--

--
-- Table structure for table `field_pass`
--

DROP TABLE IF EXISTS `field_pass`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_pass` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` char(40) NOT NULL,
  `salt` char(32) NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=ascii;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_pass`
--

LOCK TABLES `field_pass` WRITE;
/*!40000 ALTER TABLE `field_pass` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_pass` VALUES (41,'woZafR3tbCsfGNDq00jYJj2.Fld61Se','$2y$11$0w4IbzjifK.YXNaWGZECXe'),(40,'','');
/*!40000 ALTER TABLE `field_pass` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_pass` with 2 row(s)
--

--
-- Table structure for table `field_permissions`
--

DROP TABLE IF EXISTS `field_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_permissions` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_permissions`
--

LOCK TABLES `field_permissions` WRITE;
/*!40000 ALTER TABLE `field_permissions` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_permissions` VALUES (38,32,1),(38,34,2),(38,35,3),(37,36,0),(38,36,0),(38,50,4),(38,51,5),(38,52,7),(38,53,8),(38,54,6);
/*!40000 ALTER TABLE `field_permissions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_permissions` with 10 row(s)
--

--
-- Table structure for table `field_process`
--

DROP TABLE IF EXISTS `field_process`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_process` (
  `pages_id` int(11) NOT NULL DEFAULT '0',
  `data` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pages_id`),
  KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_process`
--

LOCK TABLES `field_process` WRITE;
/*!40000 ALTER TABLE `field_process` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_process` VALUES (6,17),(3,12),(8,12),(9,14),(10,7),(11,47),(16,48),(300,104),(21,50),(29,66),(23,10),(304,138),(31,136),(22,76),(30,68),(303,129),(2,87),(302,121),(301,109),(28,76),(1007,150),(1010,159),(1012,161),(1016,164),(1018,165),(1020,166);
/*!40000 ALTER TABLE `field_process` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_process` with 26 row(s)
--

--
-- Table structure for table `field_roles`
--

DROP TABLE IF EXISTS `field_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_roles` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` int(11) NOT NULL,
  `sort` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`sort`),
  KEY `data` (`data`,`pages_id`,`sort`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_roles`
--

LOCK TABLES `field_roles` WRITE;
/*!40000 ALTER TABLE `field_roles` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_roles` VALUES (40,37,0),(41,37,0),(41,38,2);
/*!40000 ALTER TABLE `field_roles` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_roles` with 3 row(s)
--

--
-- Table structure for table `field_title`
--

DROP TABLE IF EXISTS `field_title`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `field_title` (
  `pages_id` int(10) unsigned NOT NULL,
  `data` text NOT NULL,
  PRIMARY KEY (`pages_id`),
  KEY `data_exact` (`data`(255)),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `field_title`
--

LOCK TABLES `field_title` WRITE;
/*!40000 ALTER TABLE `field_title` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `field_title` VALUES (11,'Templates'),(16,'Fields'),(22,'Setup'),(3,'Pages'),(6,'Add Page'),(8,'Tree'),(9,'Save Sort'),(10,'Edit'),(21,'Modules'),(29,'Users'),(30,'Roles'),(2,'Admin'),(7,'Trash'),(27,'404 Not Found'),(302,'Insert Link'),(23,'Login'),(304,'Profile'),(301,'Empty Trash'),(300,'Search'),(303,'Insert Image'),(28,'Access'),(31,'Permissions'),(32,'Edit pages'),(34,'Delete pages'),(35,'Move pages (change parent)'),(36,'View pages'),(50,'Sort child pages'),(51,'Change templates on pages'),(52,'Administer users'),(53,'User can update profile/password'),(54,'Lock or unlock a page'),(1,'Home'),(1006,'Use Page Lister'),(1007,'Find'),(1010,'Recent'),(1011,'Can see recently edited pages'),(1012,'Logs'),(1013,'Can view system logs'),(1014,'Can manage system logs'),(1015,'Administer languages and static translation files'),(1016,'Languages'),(1017,'Default'),(1018,'Language Translator'),(1019,'Deutsch'),(1020,'Upgrades');
/*!40000 ALTER TABLE `field_title` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `field_title` with 45 row(s)
--

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) CHARACTER SET ascii NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=98 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `fieldgroups` VALUES (2,'admin'),(3,'user'),(4,'role'),(5,'permission'),(1,'home'),(83,'basic-page'),(97,'language');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `fieldgroups` with 7 row(s)
--

--
-- Table structure for table `fieldgroups_fields`
--

DROP TABLE IF EXISTS `fieldgroups_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups_fields` (
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `fields_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sort` int(11) unsigned NOT NULL DEFAULT '0',
  `data` text,
  PRIMARY KEY (`fieldgroups_id`,`fields_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups_fields`
--

LOCK TABLES `fieldgroups_fields` WRITE;
/*!40000 ALTER TABLE `fieldgroups_fields` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `fieldgroups_fields` VALUES (2,2,1,NULL),(2,1,0,NULL),(3,4,2,NULL),(3,92,1,NULL),(4,5,0,NULL),(5,1,0,NULL),(3,97,3,NULL),(83,1,0,NULL),(1,1,0,NULL),(3,3,0,NULL),(97,1,0,NULL),(97,98,1,NULL),(97,99,2,NULL),(3,100,4,NULL);
/*!40000 ALTER TABLE `fieldgroups_fields` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `fieldgroups_fields` with 14 row(s)
--

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(128) CHARACTER SET ascii NOT NULL,
  `name` varchar(250) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `label` varchar(250) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `type` (`type`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `fields` VALUES (1,'FieldtypePageTitle','title',13,'Title','{\"required\":1,\"textformatters\":[\"TextformatterEntities\"],\"size\":0,\"maxlength\":255}'),(2,'FieldtypeModule','process',25,'Process','{\"description\":\"The process that is executed on this page. Since this is mostly used by ProcessWire internally, it is recommended that you don\'t change the value of this unless adding your own pages in the admin.\",\"collapsed\":1,\"required\":1,\"moduleTypes\":[\"Process\"],\"permanent\":1}'),(3,'FieldtypePassword','pass',24,'Set Password','{\"collapsed\":1,\"size\":50,\"maxlength\":128}'),(5,'FieldtypePage','permissions',24,'Permissions','{\"derefAsPage\":0,\"parent_id\":31,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldCheckboxes\"}'),(4,'FieldtypePage','roles',24,'Roles','{\"derefAsPage\":0,\"parent_id\":30,\"labelFieldName\":\"name\",\"inputfield\":\"InputfieldCheckboxes\",\"description\":\"User will inherit the permissions assigned to each role. You may assign multiple roles to a user. When accessing a page, the user will only inherit permissions from the roles that are also assigned to the page\'s template.\"}'),(92,'FieldtypeEmail','email',9,'E-Mail Address','{\"size\":70,\"maxlength\":255}'),(97,'FieldtypeModule','admin_theme',8,'Admin Theme','{\"moduleTypes\":[\"AdminTheme\"],\"labelField\":\"title\",\"inputfieldClass\":\"InputfieldRadios\"}'),(98,'FieldtypeFile','language_files_site',24,'Site Translation Files','{\"extensions\":\"json csv\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"description\":\"Use this field for translations specific to your site (like files in \\/site\\/templates\\/ for example).\",\"descriptionRows\":0,\"fileSchema\":14}'),(99,'FieldtypeFile','language_files',24,'Core Translation Files','{\"extensions\":\"json csv\",\"maxFiles\":0,\"inputfieldClass\":\"InputfieldFile\",\"unzip\":1,\"description\":\"Use this field for [language packs](http:\\/\\/modules.processwire.com\\/categories\\/language-pack\\/). To delete all files, double-click the trash can for any file, then save.\",\"descriptionRows\":0,\"fileSchema\":14}'),(100,'FieldtypePage','language',24,'Language','{\"derefAsPage\":1,\"parent_id\":1016,\"labelFieldName\":\"title\",\"inputfield\":\"InputfieldRadios\",\"required\":1}');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `fields` with 10 row(s)
--

--
-- Table structure for table `modules`
--

DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `modules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(128) CHARACTER SET ascii NOT NULL,
  `flags` int(11) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `class` (`class`)
) ENGINE=MyISAM AUTO_INCREMENT=168 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `modules`
--

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `modules` VALUES (1,'FieldtypeTextarea',0,'','2019-10-30 21:55:18'),(2,'FieldtypeNumber',0,'','2019-10-30 21:55:18'),(3,'FieldtypeText',0,'','2019-10-30 21:55:18'),(4,'FieldtypePage',0,'','2019-10-30 21:55:18'),(30,'InputfieldForm',0,'','2019-10-30 21:55:18'),(6,'FieldtypeFile',0,'','2019-10-30 21:55:18'),(7,'ProcessPageEdit',1,'','2019-10-30 21:55:18'),(10,'ProcessLogin',0,'','2019-10-30 21:55:18'),(12,'ProcessPageList',0,'{\"pageLabelField\":\"title\",\"paginationLimit\":25,\"limit\":50}','2019-10-30 21:55:18'),(121,'ProcessPageEditLink',1,'','2019-10-30 21:55:18'),(14,'ProcessPageSort',0,'','2019-10-30 21:55:18'),(15,'InputfieldPageListSelect',0,'','2019-10-30 21:55:18'),(117,'JqueryUI',1,'','2019-10-30 21:55:18'),(17,'ProcessPageAdd',0,'','2019-10-30 21:55:18'),(125,'SessionLoginThrottle',11,'','2019-10-30 21:55:18'),(122,'InputfieldPassword',0,'','2019-10-30 21:55:18'),(25,'InputfieldAsmSelect',0,'','2019-10-30 21:55:18'),(116,'JqueryCore',1,'','2019-10-30 21:55:18'),(27,'FieldtypeModule',0,'','2019-10-30 21:55:18'),(28,'FieldtypeDatetime',0,'','2019-10-30 21:55:18'),(29,'FieldtypeEmail',0,'','2019-10-30 21:55:18'),(108,'InputfieldURL',0,'','2019-10-30 21:55:18'),(32,'InputfieldSubmit',0,'','2019-10-30 21:55:18'),(33,'InputfieldWrapper',0,'','2019-10-30 21:55:18'),(34,'InputfieldText',0,'','2019-10-30 21:55:18'),(35,'InputfieldTextarea',0,'','2019-10-30 21:55:18'),(36,'InputfieldSelect',0,'','2019-10-30 21:55:18'),(37,'InputfieldCheckbox',0,'','2019-10-30 21:55:18'),(38,'InputfieldCheckboxes',0,'','2019-10-30 21:55:18'),(39,'InputfieldRadios',0,'','2019-10-30 21:55:18'),(40,'InputfieldHidden',0,'','2019-10-30 21:55:18'),(41,'InputfieldName',0,'','2019-10-30 21:55:18'),(43,'InputfieldSelectMultiple',0,'','2019-10-30 21:55:18'),(45,'JqueryWireTabs',0,'','2019-10-30 21:55:18'),(46,'ProcessPage',0,'','2019-10-30 21:55:18'),(47,'ProcessTemplate',0,'','2019-10-30 21:55:18'),(48,'ProcessField',32,'','2019-10-30 21:55:18'),(50,'ProcessModule',0,'','2019-10-30 21:55:18'),(114,'PagePermissions',3,'','2019-10-30 21:55:18'),(97,'FieldtypeCheckbox',1,'','2019-10-30 21:55:18'),(115,'PageRender',3,'{\"clearCache\":1}','2019-10-30 21:55:18'),(55,'InputfieldFile',0,'','2019-10-30 21:55:18'),(56,'InputfieldImage',0,'','2019-10-30 21:55:18'),(57,'FieldtypeImage',0,'','2019-10-30 21:55:18'),(60,'InputfieldPage',0,'{\"inputfieldClasses\":[\"InputfieldSelect\",\"InputfieldSelectMultiple\",\"InputfieldCheckboxes\",\"InputfieldRadios\",\"InputfieldAsmSelect\",\"InputfieldPageListSelect\",\"InputfieldPageListSelectMultiple\"]}','2019-10-30 21:55:18'),(61,'TextformatterEntities',0,'','2019-10-30 21:55:18'),(66,'ProcessUser',0,'{\"showFields\":[\"name\",\"email\",\"roles\"]}','2019-10-30 21:55:18'),(67,'MarkupAdminDataTable',0,'','2019-10-30 21:55:18'),(68,'ProcessRole',0,'{\"showFields\":[\"name\"]}','2019-10-30 21:55:18'),(76,'ProcessList',0,'','2019-10-30 21:55:18'),(78,'InputfieldFieldset',0,'','2019-10-30 21:55:18'),(79,'InputfieldMarkup',0,'','2019-10-30 21:55:18'),(80,'InputfieldEmail',0,'','2019-10-30 21:55:18'),(89,'FieldtypeFloat',1,'','2019-10-30 21:55:18'),(83,'ProcessPageView',0,'','2019-10-30 21:55:18'),(84,'FieldtypeInteger',0,'','2019-10-30 21:55:18'),(85,'InputfieldInteger',0,'','2019-10-30 21:55:18'),(86,'InputfieldPageName',0,'','2019-10-30 21:55:18'),(87,'ProcessHome',0,'','2019-10-30 21:55:18'),(90,'InputfieldFloat',0,'','2019-10-30 21:55:18'),(94,'InputfieldDatetime',0,'','2019-10-30 21:55:18'),(98,'MarkupPagerNav',0,'','2019-10-30 21:55:18'),(129,'ProcessPageEditImageSelect',1,'','2019-10-30 21:55:18'),(103,'JqueryTableSorter',1,'','2019-10-30 21:55:18'),(104,'ProcessPageSearch',1,'{\"searchFields\":\"title\",\"displayField\":\"title path\"}','2019-10-30 21:55:18'),(105,'FieldtypeFieldsetOpen',1,'','2019-10-30 21:55:18'),(106,'FieldtypeFieldsetClose',1,'','2019-10-30 21:55:18'),(107,'FieldtypeFieldsetTabOpen',1,'','2019-10-30 21:55:18'),(109,'ProcessPageTrash',1,'','2019-10-30 21:55:18'),(111,'FieldtypePageTitle',1,'','2019-10-30 21:55:18'),(112,'InputfieldPageTitle',0,'','2019-10-30 21:55:18'),(113,'MarkupPageArray',3,'','2019-10-30 21:55:18'),(131,'InputfieldButton',0,'','2019-10-30 21:55:18'),(133,'FieldtypePassword',1,'','2019-10-30 21:55:18'),(134,'ProcessPageType',33,'{\"showFields\":[]}','2019-10-30 21:55:18'),(135,'FieldtypeURL',1,'','2019-10-30 21:55:18'),(136,'ProcessPermission',1,'{\"showFields\":[\"name\",\"title\"]}','2019-10-30 21:55:18'),(137,'InputfieldPageListSelectMultiple',0,'','2019-10-30 21:55:18'),(138,'ProcessProfile',1,'{\"profileFields\":[\"pass\",\"email\",\"admin_theme\",\"language\"]}','2019-10-30 21:55:18'),(139,'SystemUpdater',1,'{\"systemVersion\":17,\"coreVersion\":\"3.0.159\"}','2019-10-30 21:55:18'),(148,'AdminThemeDefault',10,'{\"colors\":\"classic\"}','2019-10-30 21:55:18'),(149,'InputfieldSelector',42,'','2019-10-30 21:55:18'),(150,'ProcessPageLister',32,'','2019-10-30 21:55:18'),(151,'JqueryMagnific',1,'','2019-10-30 21:55:18'),(155,'InputfieldCKEditor',0,'','2019-10-30 21:55:18'),(156,'MarkupHTMLPurifier',0,'','2019-10-30 21:55:18'),(159,'ProcessRecentPages',1,'','2019-10-30 21:55:40'),(160,'AdminThemeUikit',10,'','2019-10-30 21:55:40'),(161,'ProcessLogger',1,'','2019-10-30 21:55:53'),(162,'InputfieldIcon',0,'','2019-10-30 21:55:53'),(163,'LanguageSupport',35,'{\"languagesPageID\":1016,\"defaultLanguagePageID\":1017,\"otherLanguagePageIDs\":[1019],\"languageTranslatorPageID\":1018}','2019-10-30 21:57:22'),(164,'ProcessLanguage',1,'','2019-10-30 21:57:22'),(165,'ProcessLanguageTranslator',1,'','2019-10-30 21:57:22'),(166,'ProcessWireUpgrade',1,'','2020-04-20 13:30:02'),(167,'ProcessWireUpgradeCheck',11,'','2020-04-20 13:30:03');
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `modules` with 95 row(s)
--

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) unsigned NOT NULL DEFAULT '0',
  `templates_id` int(11) unsigned NOT NULL DEFAULT '0',
  `name` varchar(128) CHARACTER SET ascii NOT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '1',
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `created` timestamp NOT NULL DEFAULT '2015-12-18 05:09:00',
  `created_users_id` int(10) unsigned NOT NULL DEFAULT '2',
  `published` datetime DEFAULT NULL,
  `sort` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_parent_id` (`name`,`parent_id`),
  KEY `parent_id` (`parent_id`),
  KEY `templates_id` (`templates_id`),
  KEY `modified` (`modified`),
  KEY `created` (`created`),
  KEY `status` (`status`),
  KEY `published` (`published`)
) ENGINE=MyISAM AUTO_INCREMENT=1021 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `pages` VALUES (1,0,1,'home',9,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',0),(2,1,2,'processwire',1035,'2019-10-30 21:55:54',40,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',5),(3,2,2,'page',21,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',0),(6,3,2,'add',21,'2019-10-30 21:55:59',40,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',1),(7,1,2,'trash',1039,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',6),(8,3,2,'list',21,'2019-10-30 21:56:07',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',0),(9,3,2,'sort',1047,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',3),(10,3,2,'edit',1045,'2019-10-30 21:56:06',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',4),(11,22,2,'template',21,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',0),(16,22,2,'field',21,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',2),(21,2,2,'module',21,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',2),(22,2,2,'setup',21,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',1),(23,2,2,'login',1035,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',4),(27,1,29,'http404',1035,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',3,'2019-10-30 22:55:18',4),(28,2,2,'access',13,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',3),(29,28,2,'users',29,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',0),(30,28,2,'roles',29,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',1),(31,28,2,'permissions',29,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',2),(32,31,5,'page-edit',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',2),(34,31,5,'page-delete',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',3),(35,31,5,'page-move',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',4),(36,31,5,'page-view',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',0),(37,30,4,'guest',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',0),(38,30,4,'superuser',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',1),(41,29,3,'admin',1,'2019-10-30 21:57:22',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',0),(40,29,3,'guest',25,'2019-10-30 21:57:22',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',1),(50,31,5,'page-sort',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',41,'2019-10-30 22:55:18',5),(51,31,5,'page-template',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',41,'2019-10-30 22:55:18',6),(52,31,5,'user-admin',25,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',41,'2019-10-30 22:55:18',10),(53,31,5,'profile-edit',1,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',41,'2019-10-30 22:55:18',13),(54,31,5,'page-lock',1,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',41,'2019-10-30 22:55:18',8),(300,3,2,'search',1045,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',6),(301,3,2,'trash',1047,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',6),(302,3,2,'link',1041,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',7),(303,3,2,'image',1041,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',2,'2019-10-30 22:55:18',8),(304,2,2,'profile',1025,'2019-10-30 21:55:18',41,'2019-10-30 21:55:18',41,'2019-10-30 22:55:18',5),(1006,31,5,'page-lister',1,'2019-10-30 21:55:18',40,'2019-10-30 21:55:18',40,'2019-10-30 22:55:18',9),(1007,3,2,'lister',1,'2019-10-30 21:55:18',40,'2019-10-30 21:55:18',40,'2019-10-30 22:55:18',9),(1010,3,2,'recent-pages',1,'2019-10-30 21:55:40',40,'2019-10-30 21:55:40',40,'2019-10-30 22:55:40',10),(1011,31,5,'page-edit-recent',1,'2019-10-30 21:55:40',40,'2019-10-30 21:55:40',40,'2019-10-30 22:55:40',10),(1012,22,2,'logs',1,'2019-10-30 21:55:53',40,'2019-10-30 21:55:53',40,'2019-10-30 22:55:53',2),(1013,31,5,'logs-view',1,'2019-10-30 21:55:53',40,'2019-10-30 21:55:53',40,'2019-10-30 22:55:53',11),(1014,31,5,'logs-edit',1,'2019-10-30 21:55:53',40,'2019-10-30 21:55:53',40,'2019-10-30 22:55:53',12),(1015,31,5,'lang-edit',1,'2019-10-30 21:57:22',41,'2019-10-30 21:57:22',41,'2019-10-30 22:57:22',13),(1016,22,2,'languages',16,'2019-10-30 21:57:22',41,'2019-10-30 21:57:22',41,'2019-10-30 22:57:22',3),(1017,1016,43,'default',16,'2019-10-30 21:57:22',41,'2019-10-30 21:57:22',41,'2019-10-30 22:57:22',0),(1018,22,2,'language-translator',1040,'2019-10-30 21:57:22',41,'2019-10-30 21:57:22',41,'2019-10-30 22:57:22',4),(1019,1016,43,'de',1,'2020-04-20 14:13:33',41,'2019-10-30 21:58:04',41,'2019-10-30 22:58:04',1),(1020,22,2,'upgrades',1,'2020-04-20 13:30:02',41,'2020-04-20 13:30:02',41,'2020-04-20 15:30:02',5);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `pages` with 49 row(s)
--

--
-- Table structure for table `pages_access`
--

DROP TABLE IF EXISTS `pages_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_access` (
  `pages_id` int(11) NOT NULL,
  `templates_id` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pages_id`),
  KEY `templates_id` (`templates_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_access`
--

LOCK TABLES `pages_access` WRITE;
/*!40000 ALTER TABLE `pages_access` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `pages_access` VALUES (37,2,'2019-10-30 21:55:18'),(38,2,'2019-10-30 21:55:18'),(32,2,'2019-10-30 21:55:18'),(34,2,'2019-10-30 21:55:18'),(35,2,'2019-10-30 21:55:18'),(36,2,'2019-10-30 21:55:18'),(50,2,'2019-10-30 21:55:18'),(51,2,'2019-10-30 21:55:18'),(52,2,'2019-10-30 21:55:18'),(53,2,'2019-10-30 21:55:18'),(54,2,'2019-10-30 21:55:18'),(1006,2,'2019-10-30 21:55:18'),(1011,2,'2019-10-30 21:55:40'),(1013,2,'2019-10-30 21:55:53'),(1014,2,'2019-10-30 21:55:53'),(1015,2,'2019-10-30 21:57:22'),(1017,2,'2019-10-30 21:57:22'),(1019,2,'2019-10-30 21:58:04');
/*!40000 ALTER TABLE `pages_access` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `pages_access` with 18 row(s)
--

--
-- Table structure for table `pages_parents`
--

DROP TABLE IF EXISTS `pages_parents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_parents` (
  `pages_id` int(10) unsigned NOT NULL,
  `parents_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`pages_id`,`parents_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_parents`
--

LOCK TABLES `pages_parents` WRITE;
/*!40000 ALTER TABLE `pages_parents` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `pages_parents` VALUES (2,1),(3,1),(3,2),(7,1),(22,1),(22,2),(28,1),(28,2),(29,1),(29,2),(29,28),(30,1),(30,2),(30,28),(31,1),(31,2),(31,28),(1016,2),(1016,22);
/*!40000 ALTER TABLE `pages_parents` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `pages_parents` with 19 row(s)
--

--
-- Table structure for table `pages_sortfields`
--

DROP TABLE IF EXISTS `pages_sortfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_sortfields` (
  `pages_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sortfield` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`pages_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_sortfields`
--

LOCK TABLES `pages_sortfields` WRITE;
/*!40000 ALTER TABLE `pages_sortfields` DISABLE KEYS */;
SET autocommit=0;
/*!40000 ALTER TABLE `pages_sortfields` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `pages_sortfields` with 0 row(s)
--

--
-- Table structure for table `session_login_throttle`
--

DROP TABLE IF EXISTS `session_login_throttle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session_login_throttle` (
  `name` varchar(128) NOT NULL,
  `attempts` int(10) unsigned NOT NULL DEFAULT '0',
  `last_attempt` int(10) unsigned NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session_login_throttle`
--

LOCK TABLES `session_login_throttle` WRITE;
/*!40000 ALTER TABLE `session_login_throttle` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `session_login_throttle` VALUES ('admin',1,1595255296);
/*!40000 ALTER TABLE `session_login_throttle` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `session_login_throttle` with 1 row(s)
--

--
-- Table structure for table `templates`
--

DROP TABLE IF EXISTS `templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) CHARACTER SET ascii NOT NULL,
  `fieldgroups_id` int(10) unsigned NOT NULL DEFAULT '0',
  `flags` int(11) NOT NULL DEFAULT '0',
  `cache_time` mediumint(9) NOT NULL DEFAULT '0',
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `fieldgroups_id` (`fieldgroups_id`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `templates`
--

LOCK TABLES `templates` WRITE;
/*!40000 ALTER TABLE `templates` DISABLE KEYS */;
SET autocommit=0;
INSERT INTO `templates` VALUES (2,'admin',2,8,0,'{\"useRoles\":1,\"parentTemplates\":[2],\"allowPageNum\":1,\"redirectLogin\":23,\"slashUrls\":1,\"noGlobal\":1,\"compile\":3,\"modified\":1572472368,\"ns\":\"ProcessWire\"}'),(3,'user',3,8,0,'{\"useRoles\":1,\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"User\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),(4,'role',4,8,0,'{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Role\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),(5,'permission',5,8,0,'{\"noChildren\":1,\"parentTemplates\":[2],\"slashUrls\":1,\"guestSearchable\":1,\"pageClass\":\"Permission\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noSettings\":1,\"noChangeTemplate\":1,\"nameContentTab\":1}'),(1,'home',1,0,0,'{\"useRoles\":1,\"noParents\":1,\"slashUrls\":1,\"compile\":3,\"modified\":1572472368,\"ns\":\"\\\\\",\"roles\":[37]}'),(29,'basic-page',83,0,0,'{\"slashUrls\":1,\"compile\":3,\"modified\":1572472368,\"ns\":\"\\\\\"}'),(43,'language',97,8,0,'{\"parentTemplates\":[2],\"slashUrls\":1,\"pageClass\":\"Language\",\"pageLabelField\":\"name\",\"noGlobal\":1,\"noMove\":1,\"noTrash\":1,\"noChangeTemplate\":1,\"noUnpublish\":1,\"compile\":3,\"nameContentTab\":1,\"modified\":1572472642}');
/*!40000 ALTER TABLE `templates` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;

-- Dumped table `templates` with 7 row(s)
--

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on: Mon, 20 Jul 2020 16:30:10 +0200
